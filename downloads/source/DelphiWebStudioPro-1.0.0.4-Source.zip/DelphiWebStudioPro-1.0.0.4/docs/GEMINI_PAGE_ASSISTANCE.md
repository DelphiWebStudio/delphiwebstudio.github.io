# Gemini page and section assistance

Last changed: 2026-11-18

Page and section creation is included in version 1.0.0 build 1, alongside selected-text assistance and reviewed changes to existing components. The original Stage 2 implementation was developed locally on November 17; its baseline checks remain dated below.

The procedures describe the current creation workflow, followed by the original increment's dated verification record. Creation now shares its entry point with **Edit existing content**, and approved existing image catalogs can populate new gallery, staff and card sections. See [Gemini assistant](GEMINI_ASSISTANT.md) and the updated illustrated guides for the complete current workflow.

## Creating something you can edit

Google Gemini is the online artificial intelligence service used by this application's optional creation assistant. It proposes a page or section from your instructions and the reference content you choose; the editor turns the approved proposal into its normal editable components. A model is the software that generates that proposal.

Access uses an API key, a secret credential created through Google AI Studio, Google's website for managing Gemini access. The key belongs to a Google project that controls usage and billing independently of the website project. Free tier is Google's limited allowance for an eligible project; keep billing disabled for the project used here. The Windows edition retains the saved key in Windows Credential Manager for your Windows account.

Open a project and choose **AI assistant** beside **Page tools**. The neutral **AI Assistant** window opens with neither mode selected and no request fields. Explicitly choose **Create**, then select a new page or a section on the current page and choose an existing page as the style reference. Both **Create** and **Edit existing content** remain visible, with the active mode highlighted. The request starts blank, with an example below it. Enter the result you want. For example:

> Create a staff directory matching Home, with six portrait spaces and editable names, roles and biographies. Use clearly marked placeholders for missing details.

For a section, a suitable request is:

> Add three panels for visitors, volunteering and community events. Give each a short description, photo space and a button linking to /contact-us.

Use an existing page's actual address when requesting a button destination. **Facts and wording to use** accepts the names, descriptions or other information the assistant must work from. Missing facts should become labeled placeholders. Review the result for accuracy; the model does not independently verify facts.

Expand **Connection details** for the model and key information; the status is **Key saved** or **Setup needed**. Confirm that the saved key belongs to a Google project on **Free tier with billing disabled**, then consent to sharing the displayed context near the preview action. These confirmations are remembered only for the running session. The assistant reuses the Windows-saved key; it does not ask for a key per project.

Choose **Preview new content**. The app requests a proposal, checks its structure and turns it into the same components used by the editor. The review lists the proposed changes and shows the new content at desktop, tablet and phone widths. Scroll within the content preview to see the whole result; the desktop preview also scrolls horizontally when the window is narrower than the page. The reference Navbar and Footer are copied only when the corresponding option is selected; they are not repeated in the content-only preview.

A new page's proposed name and address can be corrected before Apply without making another request. The address must be unique, such as `/staff-directory`. Choose **New preview** to request another result from an unchanged brief. Editing the brief clears the proposal and returns the action to **Preview new content**.

**Apply** appears when a proposal exists and adds the reviewed page or section in one undoable edit. It never replaces an existing page or changes the global theme. A section goes after the block captured when you explicitly chose **Create**, or before the footer when no block was selected. Selecting the footer also inserts before it. **Undo** appears after acceptance and restores the previous site and page selection. After closing the assistant, the editor's normal Undo and Redo commands also work.

**Close** is always available. Close, Escape and the window's close button discard an unapplied proposal. **Stop** cancels a request in progress. Closing after Apply keeps the addition unless it has been undone. Save the project normally to keep accepted changes in its project file.

## What creation can build

The supported section types are Hero, prose, cards, staff directory, FAQ, contact form, calendar and gallery. Card sections contain ordinary panels with separately editable text, optional photo spaces and buttons. Children belong to their panel, so moving it uses the existing grouped-object behavior. The normal responsive layout and export code handle these components.

The builder uses the reference content background and available reference fonts, together with the site's theme palette. It chooses readable text colors for the new backgrounds. The model supplies a bounded layout plan, not arbitrary styling or executable HTML.

Creation can use existing imported images when you separately allow Gemini to choose from the project image catalog. Only filenames, logical folders, types, dimensions and asset IDs are shared; original files stay local. A request may use up to 500 catalog entries. Without permission or a suitable existing image, photo spaces remain editable placeholders. Fill them through normal properties and media management after Apply, or use existing-content editing with its folder selector. The assistant does not read, retouch or generate photographs. New calendars contain no invented events. New contact forms contain no generated recipient or service endpoint; configure them through the usual project/form settings before expecting delivery. Previewing or applying a proposal sends no email.

Copying navigation preserves its current destinations. The assistant does not silently add a visitor Navbar link to a new page. When the page is ready, add that link through the normal Navbar controls or request it in Edit existing content. Copied Navbar/Footer blocks retain any intentional shared-section behavior already present in the reference.

Create adds content; choose Edit existing content for supported changes to the accepted page or component. Neither mode provides autonomous whole-site operation, code development, media understanding, hosting setup or publication.

## Data and free-tier boundaries

Each preview request makes one standard `generateContent` request to `gemini-3.5-flash-lite`. There are no tools, search grounding, automatic retries, alternate models or paid fallback. Google controls availability and quotas.

The API cannot force an arbitrary key onto Free tier. Billing must remain disabled on the key's Google project. The application cannot verify or change that setting. Google says free-tier content may be used to improve its products; do not supply confidential material.

The request includes the instructions and facts, site name, up to 100 page names/paths, selected theme values and a bounded text extract from the chosen reference page. It does not serialize the full project. Other pages' contents, original media files, local paths, arbitrary properties, HTML source, deployment endpoints and stored connection settings are excluded. If you separately approve image catalog access, that catalog adds file details and identifiers so the assistant can select an existing imported image. The saved Gemini credential is sent only as the API authentication header.

Limits are 3,000 instruction characters, 12,000 supporting-fact characters and 12,000 extracted reference-text characters. A page can contain one to eight new sections; section mode requires exactly one. Cards support one to four columns. Each section can have up to 12 items, with at most 36 items per page. Requests time out after 90 seconds. Generated links must target exact existing page paths. The app rejects oversized, unsupported or malformed plans rather than applying part of them.

## Implementation

`src/ai/GeminiPageAssistant.tsx` owns the neutral entry, explicit mode selection, connection details, creation request cancellation, responsive content preview and Apply/Undo controls. Choosing **Edit existing content** mounts its separate editing controls and takes the initial target from the selected item; opening the neutral window alone does not select editing. It uses the existing React editor rather than adding native runtime-built forms.

`src/ai/gemini-pages.ts` extracts allowlisted reference context, reads the existing Windows credential and sends the request. Google's transport schema uses simple types and enums; local validation enforces the stricter item, length, column and section limits. Nested numeric/array constraints in the transport schema exceeded Google's serving-state limit during testing, so those constraints are enforced locally instead.

The conversion layer constructs normal `BlockConfig` and section-object records with fresh ids. Returned wording is handled as text. The model cannot create custom HTML, scripts, external links, endpoints or arbitrary project fields. Before Apply, the app checks that both the current site and reviewed proposal still match their snapshots. An intervening edit requires a fresh preview. Apply uses the existing config store and undo stack; accepted additions use normal project serialization and export.

## Historical Stage 2 verification - November 17, 2026

These checks describe the original creation increment, before the later existing-content and targeting additions. The current November 18 release suite passed 447 tests with two pre-existing optional integration checks skipped; see [release review](RELEASE_1_0_REVIEW.md). No new live Gemini request was made for that release review.

The pre-change ZIP contains 495 files (199,551,425 bytes) and passed ZIP CRC verification. Its private location and fingerprint are omitted from this public record. It includes source, working builds, saved projects, documentation and assets. Reinstallable dependencies, generated caches, test results and duplicate Git history are excluded; the earlier complete v1.0 fallback ZIP remains preserved.

The regression suite passed 410 tests, with two existing integration tests skipped. TypeScript, the production bundle, changed-file lint and both native builds passed. Unit checks cover all eight supported section types, stale/tampered-plan rejection, unapproved/external fields, consent, request boundaries, insertion position, preservation of existing pages, exact Undo/Redo, portable save/reopen and HTML export.

Both actual desktop builds passed isolated UI tests for page and section Preview, Cancel, Apply, Undo/Redo, editable proposed names/paths, collision rejection, responsive preview, heading visibility, Stop and quota errors without retry. Each architecture also made two live Gemini requests using only a synthetic reference page: an editable staff-directory page and a two-panel section. Preview left the site unchanged, Apply added the normal components, and Undo restored the exact original site and page selection. No user project was opened and no key contents were logged.

The repeatable desktop check is `tests/browser/gemini-pages.mjs`. It requires an isolated WebView profile, which separates the test browser's stored data, and a loopback CDP address. CDP (Chrome DevTools Protocol) lets the test control the browser on this computer. The current repeatable script uses simulated credentials and replies and rejects live-mode opt-in. The historical live checks described above were separately authorized tests; this regression script does not perform them. Compact screenshots/results are retained in ignored `test-results/gemini-pages`; disposable profiles and generated caches are removed after validation.

Both architectures also passed a final check editing generated card text through the normal text editor, undoing that edit while keeping the section, and then undoing the section. The test applications were closed. Cleanup removed 655 disposable files totaling 152.69 MiB, including both test profiles, their shader cache, the generated frontend build copy and generated DCUs. The staged editor bundles in `bin/Win32/editor` and `bin/Win64/editor` remain intact. Both saved project ZIPs retained the SHA-256 values recorded before this development.

Official references: [structured output](https://ai.google.dev/gemini-api/docs/structured-output), [model and free-tier pricing](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-flash-lite), and [billing](https://ai.google.dev/gemini-api/docs/billing).
