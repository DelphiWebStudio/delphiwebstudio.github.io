import { describe, it, expect } from 'vitest'
import { editContext, editTargets, resolveEditTarget, previewEdits, acceptEdits, refineEdits, type EditOperation } from '@/ai/gemini-edits'
import type { SiteConfig } from '@/blocks/types'
import { useConfigStore } from '@/store/configStore'
import { createProjectFile, serializeProjectFile, parseProjectFile } from '@/project/project-file'
import { exportSiteToHTML } from '@/lib/export-html'

const objects = [{ id: 'panel', type: 'panel', text: '', x: 10, y: 100, width: 50, height: 300, layer: 1, color: '#eeeeee' }, { id: 'text', parentId: 'panel', type: 'text', text: 'Welcome friends', x: 12, y: 120, width: 45, height: 70, layer: 2, textColor: '#000000' }]
const blocks = [{ id: 'hero', type: 'hero' as const, variant: 'minimal', props: { headline: 'Welcome friends', subheadline: 'Keep this text', headlineRich: [{ text: 'Welcome ', font: 'Georgia', bold: true, color: '#000000', line: 1 }, { text: 'friends', href: '/visit', font: 'Georgia', color: '#123456', line: 1 }], section1Objects: objects, apiKey: 'SECRET', formEndpoint: 'PRIVATE_ENDPOINT' } }, { id: 'footer', type: 'footer' as const, variant: 'simple', props: { copyright: 'Untouched' } }]
const config: SiteConfig = { name: 'Synthetic fixture', blocks, pages: [{ id: 'home', name: 'Home', path: '/', blocks }, { id: 'visit', name: 'Visit', path: '/visit', blocks: [{ id: 'private', type: 'content', variant: 'prose', props: { body: 'PRIVATE OTHER PAGE' } }] }] }
const scope = { pageId: 'home', target: 'page:home' }
const op = (action: EditOperation['action'], target: string, field: string, value: unknown): EditOperation => ({ action, target, field, value: JSON.stringify(value) })
const plan = (...operations: EditOperation[]) => ({ summary: 'Reviewed edits', operations })
describe('explicit AI edit subjects', () => {
  const fixture = structuredClone(config)
  fixture.pages![0].blocks.splice(1, 0, { id: 'body', type: 'content', variant: 'prose', props: { body: '## Parish news\n\nKeep this lower section.', blockBackgroundColor: '#ffffff' } })
  fixture.blocks = fixture.pages![0].blocks
  it('narrows whole-page hero and banner requests to the actual hero', () => {
    for (const request of ['Change the hero section color to yellow', 'Please change the banner background to yellow', 'Set the background of the hero to yellow']) {
      expect(resolveEditTarget(fixture, scope, request)).toMatchObject({ scope: { pageId: 'home', target: 'block:hero' }, explicit: true, backgroundOnly: true })
      const preview = previewEdits(fixture, scope, plan(op('set', 'block:hero', 'blockBackgroundColor', '#ffff00')), [], request)
      expect(preview.config.blocks[0].props.blockBackgroundColor).toBe('#ffff00')
      expect(preview.config.blocks[1]).toEqual(fixture.blocks[1])
      expect(() => previewEdits(fixture, scope, plan(op('set', 'block:body', 'blockBackgroundColor', '#ffff00')), [], request)).toThrow('outside')
    }
  })
  it('blocks conflicting selections, including a child of the named block', () => {
    for (const target of ['block:body', 'object:hero:1:panel', 'object:hero:1:text']) {
      const resolved = resolveEditTarget(fixture, { pageId: 'home', target }, 'Change the hero section color to yellow')
      expect(resolved.conflict).toContain('currently selects')
      expect(resolved.candidates).toMatchObject([{ id: 'block:hero' }])
      expect(() => previewEdits(fixture, { pageId: 'home', target }, plan(op('set', 'block:body', 'blockBackgroundColor', '#ffff00')), [], 'Change the hero background to yellow')).toThrow('currently selects')
    }
  })
  it('requires the named section background rather than a child or automatic text recoloring', () => {
    const request = 'Change the hero background to yellow'
    expect(() => previewEdits(fixture, scope, plan(op('set', 'object:hero:1:panel', 'backgroundColor', '#ffff00')), [], request)).toThrow('only the named section')
    expect(() => previewEdits(fixture, scope, plan(op('set', 'block:hero', 'blockBackgroundColor', '#ffff00'), op('set', 'block:hero', 'textColor', '#000000')), [], request)).toThrow('only the named section')
    expect(() => previewEdits(fixture, scope, plan(op('set', 'block:hero', 'blockBackgroundColor', '#ffff00'), op('set', 'block:hero', 'textColor', '#000000')), [], 'Change the hero background to yellow and its text color to black')).not.toThrow()
    for (const combined of ['Change the hero background to yellow and keep its text unchanged', 'Change the hero background to yellow and its text color to black']) {
      expect(() => previewEdits(fixture, scope, plan(op('set', 'object:hero:1:panel', 'backgroundColor', '#ffff00')), [], combined)).toThrow('named section’s background')
    }
  })
  it('resolves exact headings and explicit positions', () => {
    expect(resolveEditTarget(fixture, scope, 'Change the section titled "Welcome friends" background to yellow').scope.target).toBe('block:hero')
    expect(resolveEditTarget(fixture, scope, 'Change the "Welcome friends" section color to yellow').scope.target).toBe('block:hero')
    expect(resolveEditTarget(fixture, scope, 'Change the Welcome friends section background to yellow').scope.target).toBe('block:hero')
    expect(resolveEditTarget(fixture, scope, 'Make Welcome friends yellow')).toMatchObject({ scope: { target: 'block:hero' }, backgroundOnly: true })
    expect(resolveEditTarget(fixture, scope, 'Change the block titled "Parish news" color to yellow').scope.target).toBe('block:body')
    expect(resolveEditTarget(fixture, scope, 'Change the first section color to yellow').scope.target).toBe('block:hero')
    expect(resolveEditTarget(fixture, scope, 'Change section 2 color to yellow').scope.target).toBe('block:body')
    expect(resolveEditTarget(fixture, scope, 'Change the bottom block color to yellow').scope.target).toBe('block:footer')
    const named = structuredClone(fixture)
    named.pages![0].blocks[0].props.headline = 'Welcome to Faith and Family'
    expect(resolveEditTarget(named, scope, 'Change the section titled "Welcome to Faith and Family" background to yellow')).toMatchObject({ scope: { target: 'block:hero' }, backgroundOnly: true })
  })
  it('does not guess between duplicate heroes, but accepts a matching selected hero', () => {
    const duplicate = structuredClone(fixture)
    duplicate.pages![0].blocks.push({ id: 'hero-two', type: 'hero', variant: 'minimal', props: { headline: 'Second hero' } }); duplicate.blocks = duplicate.pages![0].blocks
    expect(resolveEditTarget(duplicate, scope, 'Change the hero background to yellow')).toMatchObject({ conflict: expect.stringContaining('More than one'), candidates: [{ id: 'block:hero', label: expect.any(String) }, { id: 'block:hero-two', label: expect.any(String) }] })
    const selected = resolveEditTarget(duplicate, { pageId: 'home', target: 'block:hero-two' }, 'Change the hero background to yellow')
    expect(selected.scope.target).toBe('block:hero-two'); expect(selected.conflict).toBeUndefined()
    expect(resolveEditTarget(duplicate, scope, 'Change the last hero section color to yellow').scope.target).toBe('block:hero-two')
  })
  it('keeps creation, navigation destinations, quoted replacements and ordinary follow-ups in their selected scope', () => {
    for (const request of ['Add a hero with a yellow background', 'Link this text to the footer', 'Change this text to "the hero section"', 'Change the link to the footer', 'Make it smaller', 'Make this panel narrower and change its background to light blue', 'Make this Panel narrower', 'Do not change the footer', 'Keep the hero unchanged']) {
      expect(resolveEditTarget(fixture, { pageId: 'home', target: 'object:hero:1:panel' }, request)).toMatchObject({ scope: { target: 'object:hero:1:panel' }, explicit: false })
    }
    expect(resolveEditTarget(fixture, scope, 'Change the hero background, do not change the footer').scope.target).toBe('block:hero')
    expect(resolveEditTarget(fixture, scope, 'Change the hero background and footer color')).toMatchObject({ scope, explicit: false })
    expect(resolveEditTarget(fixture, { pageId: 'home', target: 'block:hero' }, 'Change the hero background and footer color').conflict).toContain('whole page')
    expect(resolveEditTarget(fixture, { pageId: 'home', target: 'block:hero' }, 'Change the hero image to an existing photo')).toMatchObject({ scope: { target: 'block:hero' }, explicit: true })
    const navigation = structuredClone(fixture)
    navigation.pages![0].blocks.unshift({ id: 'nav', type: 'navbar', variant: 'default', props: { logo: 'Parish' } }); navigation.blocks = navigation.pages![0].blocks
    expect(resolveEditTarget(navigation, { pageId: 'home', target: 'block:nav' }, 'Change the navbar logo image to an existing photo')).toMatchObject({ scope: { target: 'block:nav' }, explicit: true })
  })
  it('returns local conflicts for missing components without throwing during typing', () => {
    expect(resolveEditTarget(fixture, scope, 'Change the calendar background to yellow').conflict).toContain('No matching')
    expect(resolveEditTarget(fixture, scope, 'Change section named Missing background to yellow').conflict).toContain('No matching')
    expect(resolveEditTarget(fixture, { pageId: 'home', target: 'block:body' }, 'Change the Missing News section background to yellow').conflict).toContain('No matching')
    expect(resolveEditTarget(fixture, scope, 'Change the FAQ background to yellow').conflict).toContain('No matching')
    expect(resolveEditTarget(fixture, scope, 'Change section 20 color to yellow').conflict).toContain('No matching')
    expect(resolveEditTarget(fixture, { pageId: 'missing', target: 'page:missing' }, 'Change hero color').conflict).toContain('page no longer exists')
    expect(resolveEditTarget(fixture, { pageId: 'home', target: 'block:missing' }, 'Change hero color').conflict).toContain('component no longer exists')
  })
  it('does not mistake color words in a section name for a background request', () => {
    const named = structuredClone(fixture)
    named.pages![0].blocks[0].props.headline = 'Black History'; named.blocks = named.pages![0].blocks
    for (const request of ['Move Black History section down', 'Remove the Black History section', 'Make Black History section more welcoming']) {
      expect(resolveEditTarget(named, scope, request)).toMatchObject({ scope: { target: 'block:hero' }, backgroundRequested: false, backgroundOnly: false })
    }
    expect(() => previewEdits(named, scope, plan(op('move', 'block:hero', '', { index: 1 })), [], 'Move Black History section down')).not.toThrow()
    expect(() => previewEdits(named, scope, plan(op('remove', 'block:hero', '', null)), [], 'Remove the Black History section')).not.toThrow()
    expect(resolveEditTarget(named, scope, 'Make Black History section yellow')).toMatchObject({ backgroundRequested: true, backgroundOnly: true })
  })
  it('resolves the complete named heading before a shorter selected prefix or generic type word', () => {
    const named = structuredClone(fixture)
    named.pages![0].blocks[0].props.headline = 'Welcome'
    named.pages![0].blocks[1].props.title = 'Welcome Visitors'; named.blocks = named.pages![0].blocks
    const longer = resolveEditTarget(named, { pageId: 'home', target: 'block:hero' }, 'Change Welcome Visitors section background to yellow')
    expect(longer.scope.target).toBe('block:body'); expect(longer.conflict).toContain('currently selects')
    named.pages![0].blocks[1].props.title = 'Community Hero'
    expect(resolveEditTarget(named, scope, 'Change the background of the Community Hero section to yellow').scope.target).toBe('block:body')
  })
  it('uses the named block as owner when changing an image inside that block', () => {
    const withImage = structuredClone(fixture)
    withImage.pages![0].blocks.push({ id: 'standalone-image', type: 'image', variant: 'default', props: { src: 'assets/existing.jpg', alt: 'Separate image' } }); withImage.blocks = withImage.pages![0].blocks
    for (const request of ['Change the image in the hero to the existing photo', 'Change the image inside the hero to the existing photo', 'Change the image within the hero to the existing photo']) {
      const resolved = resolveEditTarget(withImage, scope, request)
      expect(resolved.scope.target).toBe('block:hero'); expect(resolved.conflict).toBeUndefined()
    }
  })
  it('validates named refinements against the proposed state while retaining earlier edits', () => {
    const first = previewEdits(fixture, scope, plan(op('set', 'block:hero', 'headlineWidth', 500)))
    const refined = refineEdits(fixture, scope, first, plan(op('set', 'block:hero', 'blockBackgroundColor', '#ffff00')), [], 'Change the hero background to yellow')
    expect(refined.config.blocks[0].props).toMatchObject({ headlineWidth: 500, blockBackgroundColor: '#ffff00' })
    expect(refined.config.blocks[1]).toEqual(fixture.blocks[1])
    expect(() => refineEdits(fixture, scope, first, plan(op('set', 'block:body', 'blockBackgroundColor', '#ffff00')), [], 'Change the hero background to yellow')).toThrow('outside')
  })
})

describe('Gemini editing of existing content', () => {
  it('exposes normal scalar properties and exact targets without credentials or other-page content', () => {
    const context = JSON.stringify(editContext(config, { pageId: 'home', target: 'block:hero' }))
    expect(context).toContain('headline'); expect(context).toContain('headlineWidth')
    expect(context).not.toMatch(/SECRET|PRIVATE_ENDPOINT|PRIVATE OTHER PAGE/)
    expect(editTargets(config, 'home').some(target => target.id === 'object:hero:1:text')).toBe(true)
  })
  it('previews complete edits on a clone and preserves other content', () => {
    const original = structuredClone(config)
    const preview = previewEdits(config, scope, plan(op('set', 'block:hero', 'headline', 'A warmer welcome'), op('set', 'block:hero', 'blockBackgroundColor', '#eeeeee')))
    expect(config).toEqual(original); expect(preview.config.pages![1]).toEqual(config.pages![1])
    expect(preview.config.blocks[0].props.subheadline).toBe('Keep this text')
    expect(preview.config.blocks[0].props.headlineRich).toMatchObject([{ font: 'Georgia', bold: true, text: 'A warmer welcome' }])
    expect(acceptEdits(config, preview)).toEqual(preview.config)
  })
  it('accepts plain scalar color strings but still rejects wrong types and rendered layout overflow', () => {
    const preview = previewEdits(config, scope, plan({ action: 'set', target: 'block:hero', field: 'blockBackgroundColor', value: '#dceafa' }))
    expect(preview.config.blocks[0].props.blockBackgroundColor).toBe('#dceafa')
    expect(() => previewEdits(config, scope, plan({ action: 'set', target: 'block:hero', field: 'layoutWidth', value: 'narrow' }))).toThrow('Invalid')
    expect(() => previewEdits(config, scope, plan(op('set', 'block:hero', 'layoutTop', 5000)))).toThrow('Invalid')
  })
  it('formats only an exact phrase while retaining the rest and existing links', () => {
    const preview = previewEdits(config, scope, plan(op('textStyle', 'block:hero', 'headline', { text: 'friends', size: 28, color: '#0000ff' })))
    expect(preview.config.blocks[0].props.headlineRich).toEqual([{ text: 'Welcome ', font: 'Georgia', bold: true, color: '#000000', line: 1 }, { text: 'friends', href: '/visit', font: 'Georgia', color: '#0000ff', size: 28, line: 1 }])
  })
  it('moves a panel with its children and edits independent text', () => {
    const preview = previewEdits(config, scope, plan(op('move', 'object:hero:1:panel', '', { x: 20, y: 200 }), op('set', 'object:hero:1:text', 'text', 'Revised text')))
    const saved = preview.config.blocks[0].props.section1Objects as typeof objects
    expect(saved[0]).toMatchObject({ x: 20, y: 200 }); expect(saved[1]).toMatchObject({ x: 22, y: 220, text: 'Revised text' })
    const scalar = previewEdits(config, scope, plan(op('set', 'object:hero:1:panel', 'x', 20)))
    expect((scalar.config.blocks[0].props.section1Objects as typeof objects)[1].x).toBe(22)
  })
  it('adds and removes normal objects and reorders blocks', () => {
    const preview = previewEdits(config, scope, plan(op('addObject', 'object:hero:1:panel', '', { type: 'text', text: 'New child', x: 14, y: 200, width: 40, height: 60 }), op('move', 'block:footer', '', { index: 0 })))
    expect(preview.config.blocks[0].id).toBe('footer')
    expect((preview.config.blocks[1].props.section1Objects as Record<string, unknown>[]).at(-1)).toMatchObject({ type: 'text', parentId: 'panel', text: 'New child' })
    const deleted = previewEdits(config, scope, plan(op('remove', 'object:hero:1:panel', '', null)))
    expect(deleted.config.blocks[0].props.section1Objects).toEqual([])
  })
  it('rejects scope escape, scripts, invalid colors and incomplete transactions', () => {
    expect(() => previewEdits(config, { pageId: 'home', target: 'object:hero:1:text' }, plan(op('set', 'block:hero', 'headline', 'Bad')))).toThrow('outside')
    expect(() => previewEdits(config, scope, plan(op('set', 'block:hero', 'apiKey', 'Bad')))).toThrow('property')
    expect(() => previewEdits(config, scope, plan(op('set', 'block:hero', 'textColor', 'url(javascript:bad)')))).toThrow('Invalid')
    expect(() => previewEdits(config, scope, plan(op('set', 'block:hero', 'headline', 'Good'), op('set', 'block:footer', 'unknown', 'Bad')))).toThrow()
    expect(config.blocks[0].props.headline).toBe('Welcome friends')
  })
  it('rejects stale proposals and keeps the complete edit in normal Undo/Redo', () => {
    const preview = previewEdits(config, scope, plan(op('set', 'block:hero', 'headlineWidth', 500)))
    expect(() => acceptEdits({ ...config, name: 'Changed' }, preview)).toThrow('changed')
    useConfigStore.getState().setConfig(config); useConfigStore.getState().replaceConfig(acceptEdits(config, preview), 'Gemini: edit website')
    useConfigStore.getState().undo(); expect(useConfigStore.getState().config).toEqual(config)
    useConfigStore.getState().redo(); expect(useConfigStore.getState().config).toEqual(preview.config)
  })
  it('preserves AI changes through the normal portable serializer and static website exporter', () => {
    const preview = previewEdits(config, scope, plan(op('set', 'block:hero', 'blockBackgroundColor', '#dceafa'), op('linkText', 'block:hero', 'headline', { text: 'friends', url: '/visit' }), op('addObject', 'block:hero', '', { type: 'button', text: 'Visit us', x: 5, y: 300, width: 30, height: 44 })))
    const reopened = parseProjectFile(serializeProjectFile(createProjectFile(acceptEdits(config, preview), 'ai-edit-save-test'))).project.config
    expect(reopened).toEqual(preview.config)
    const html = exportSiteToHTML(reopened)
    expect(html).toContain('#dceafa'); expect(html).toContain('Visit us'); expect(html).toMatch(/href="(?:visit\/|\/visit|visit\.html)/)
  })
  it('refines an unapplied preview against its proposed state and applies the combined result once', () => {
    const first = previewEdits(config, scope, plan(op('set', 'block:hero', 'headlineWidth', 500)))
    const refined = refineEdits(config, scope, first, plan(op('set', 'block:hero', 'headlineWidth', 400), op('set', 'block:hero', 'textColor', '#123456')))
    expect(refined.before).toBe(JSON.stringify(config)); expect(refined.config.blocks[0].props.headlineWidth).toBe(400)
    expect(refined.changes).toHaveLength(3); expect(acceptEdits(config, refined).blocks[0].props.textColor).toBe('#123456')
    expect(() => refineEdits({ ...config, name: 'Intervening edit' }, scope, first, plan(op('set', 'block:hero', 'headlineWidth', 300)))).toThrow('changed')
  })
  it('uses existing media by id, preserving paths, captions and gallery ids through replacement and reorder', () => {
    const catalog = [{ id: 'photo1', name: 'Church.jpg', path: 'assets/photo1.jpg', mime: 'image/jpeg', folder: 'Church' }, { id: 'photo2', name: 'Portrait.jpg', path: 'assets/photo2.jpg', mime: 'image/jpeg' }, { id: 'bulletin', name: 'Bulletin.pdf', path: 'assets/bulletin.pdf', mime: 'application/pdf' }]
    const gallery = { id: 'gallery', type: 'gallery' as const, variant: 'responsive', props: { images: [{ id: 'existing', src: 'assets/photo1.jpg', assetId: 'photo1', caption: 'Keep caption', alt: 'Church' }] } }
    const fixture = structuredClone(config); fixture.pages![0].blocks.push(gallery); fixture.blocks = fixture.pages![0].blocks
    const preview = previewEdits(fixture, scope, plan(op('setMedia', 'item:gallery:images:existing', 'src', 'photo2'), op('addItem', 'block:gallery', 'images', { assetId: 'photo1', caption: 'New caption', alt: 'Church photo' })), catalog)
    const photos = preview.config.blocks.at(-1)!.props.images as Record<string, unknown>[]
    expect(() => previewEdits(fixture, { pageId: 'home', target: 'item:gallery:images:existing' }, plan(op('addObject', 'item:gallery:images:existing', '', { type: 'text', text: 'Outside selected item' })))).toThrow('block or panel')
    expect(photos[0]).toMatchObject({ id: 'existing', src: 'assets/photo2.jpg', assetId: 'photo2', caption: 'Keep caption' })
    expect(photos[1]).toMatchObject({ src: 'assets/photo1.jpg', assetId: 'photo1', caption: 'New caption' })
    expect(typeof photos[1].id).toBe('string')
    const context = JSON.stringify(editContext(fixture, scope, catalog))
    expect(context).toContain('Church.jpg'); expect(context).not.toContain('assets/photo2.jpg')
    expect(() => previewEdits(fixture, scope, plan(op('setMedia', 'item:gallery:images:existing', 'src', 'missing')), catalog)).toThrow('approved')
    expect(() => previewEdits(fixture, scope, plan(op('setMedia', 'item:gallery:images:existing', 'src', 'bulletin')), catalog)).toThrow('media type')
    const ordered = previewEdits(preview.config, scope, plan(op('move', 'item:gallery:images:' + photos[1].id, '', { index: 0 }), op('set', 'item:gallery:images:existing', 'caption', 'Revised caption')), catalog)
    expect((ordered.config.blocks.at(-1)!.props.images as Record<string, unknown>[])[1]).toMatchObject({ id: 'existing', caption: 'Revised caption' })
  })
  it('adds actual staff, bulletin and calendar data without replacing existing entries or inventing dates', () => {
    const fixture = structuredClone(config)
    fixture.pages![0].blocks.push({ id: 'staff', type: 'team', variant: 'directory', props: { members: [{ name: 'Existing member', role: 'Role', bio: 'Keep biography' }] } }, { id: 'calendar', type: 'calendar', variant: 'default', props: { events: [] } }, { id: 'bulletins', type: 'documentLibrary', variant: 'weekly-bulletins', props: { items: [] } })
    fixture.blocks = fixture.pages![0].blocks
    const catalog = [{ id: 'pdf', name: 'Bulletin.pdf', path: 'assets/bulletin.pdf', mime: 'application/pdf' }]
    const preview = previewEdits(fixture, scope, plan(op('addItem', 'block:staff', 'members', { name: 'New member', role: 'Volunteer', bio: 'Provided biography' }), op('addItem', 'block:calendar', 'events', { title: 'Provided event', date: '2026-11-20', time: '18:30' }), op('addItem', 'block:bulletins', 'items', { title: 'Current bulletin', assetId: 'pdf' })), catalog)
    expect((preview.config.blocks.find(block => block.id === 'staff')!.props.members as unknown[])[0]).toEqual(fixture.blocks.find(block => block.id === 'staff')!.props.members && { name: 'Existing member', role: 'Role', bio: 'Keep biography' })
    expect(preview.config.blocks.find(block => block.id === 'bulletins')!.props.items).toMatchObject([{ src: 'assets/bulletin.pdf', assetId: 'pdf' }])
    expect(() => previewEdits(fixture, scope, plan(op('addItem', 'block:calendar', 'events', { title: 'Invalid', date: '2026-02-30' })))).toThrow('real date')
  })
  it('keeps parent navigation clickable, adds submenus and links exact text without losing rich formatting', () => {
    const fixture = structuredClone(config)
    fixture.pages![0].blocks.push({ id: 'nav', type: 'navbar', variant: 'default', props: { navItems: [{ id: 'about', label: 'About', url: '/visit', children: [] }] } })
    fixture.blocks = fixture.pages![0].blocks
    const preview = previewEdits(fixture, scope, plan(op('addItem', 'item:nav:navItems:about', 'children', { label: 'Staff', url: '/visit' }), op('linkText', 'block:hero', 'headline', { text: 'friends', url: 'https://webstudio.local/visit' })))
    const nav = preview.config.blocks.find(block => block.id === 'nav')!.props.navItems as Record<string, unknown>[]
    expect(nav[0]).toMatchObject({ label: 'About', url: '/visit', children: [{ label: 'Staff', url: '/visit' }] })
    expect(preview.config.blocks[0].props.headlineRich).toMatchObject([{ text: 'Welcome ', bold: true, color: '#000000' }, { text: 'friends', href: '/visit', font: 'Georgia' }])
    expect(() => previewEdits(fixture, scope, plan(op('set', 'item:nav:navItems:about', 'url', '/missing')))).toThrow('missing')
    expect(() => previewEdits(fixture, scope, plan(op('set', 'item:nav:navItems:about', 'url', 'javascript:alert(1)')))).toThrow('Only')
  })
  it('creates and renames anchors and repairs incoming links while preserving other pages', () => {
    const fixture = structuredClone(config)
    fixture.pages![0].blocks[0].props = { ...fixture.blocks[0].props, anchorName: 'welcome' }
    fixture.pages![1].blocks[0].props = { body: 'Go to welcome', bodyRich: [{ text: 'welcome', href: '/#welcome' }] }
    fixture.blocks = fixture.pages![0].blocks
    const preview = previewEdits(fixture, scope, plan(op('set', 'block:hero', 'anchorName', 'greeting'), op('linkText', 'block:hero', 'headline', { text: 'friends', url: '#greeting' })))
    expect(preview.config.pages![1].blocks[0].props.bodyRich).toMatchObject([{ href: '/#greeting' }])
    expect(preview.affectedPages).toEqual(['home', 'visit'])
    expect(() => previewEdits(fixture, scope, plan(op('linkText', 'block:hero', 'headline', { text: 'friends', url: '#missing' })))).toThrow('anchor')
  })
  it('preserves markdown headings, lists and emphasis when adding an inline link', () => {
    const fixture = structuredClone(config)
    fixture.pages![0].blocks.push({ id: 'prose', type: 'content', variant: 'prose', props: { body: '## Community Venues\n\n- **Community Hall** in Exampletown\n- Another venue' } })
    fixture.blocks = fixture.pages![0].blocks
    const preview = previewEdits(fixture, scope, plan(op('linkText', 'block:prose', 'body', { text: 'Community Hall', url: '/visit' })))
    const runs = preview.config.blocks.at(-1)!.props.bodyRich as Record<string, unknown>[]
    expect(runs[0]).toMatchObject({ text: 'Community Venues', tag: 'h2' })
    expect(runs.some(run => run.text === 'Community Hall' && run.bold === true && run.href === '/visit' && run.tag === 'li')).toBe(true)
  })
})
