import type { BlockType } from '@/blocks/types'

export interface BlockMeta {
  type: BlockType
  label: string
  description: string
  category: string
  variants: string[]
  defaultProps: Record<string, unknown>
}

export const blockMetadata: BlockMeta[] = [
  { type: 'collage', label: 'Photo collage', description: 'Move and layer photos and other images', category: 'Media', variants: ['default'], defaultProps: { images: [] } },
  { type: 'panel', label: 'Panel', description: 'Movable colored panel with image and text', category: 'Content', variants: ['default'], defaultProps: { title: 'Panel title', body: 'Add your text here.', src: '', alt: '', blockBackgroundColor: '#b9aeb6', layoutWidth: 40 } },
  { type: 'documentLibrary', label: 'Document library', description: 'Searchable list of documents', category: 'Media', variants: ['default'], defaultProps: { title: 'Documents', items: [] } },
  { type: 'calendar', label: 'Calendar', description: 'Monthly calendar with editable events', category: 'Content', variants: ['default'], defaultProps: { title: 'Calendar', intro: '', events: [] } },
  {
    type: 'navbar',
    label: 'Navbar',
    description: 'Navigation bar with editable text links',
    category: 'Navigation',
    variants: ['default', 'centered'],
    defaultProps: { logo: '', links: [], navItems: [{ label: 'Home', url: '/' }], ctaText: '' },
  },
  {
    type: 'hero',
    label: 'Hero',
    description: 'Full-width hero section with headline and CTAs',
    category: 'Hero',
    variants: ['centered', 'split', 'gradient', 'minimal'],
    defaultProps: { headline: 'Your Headline Here', subheadline: 'A compelling subheadline that explains your value proposition.', primaryCta: '', secondaryCta: '' },
  },
  {
    type: 'features',
    label: 'Features',
    description: 'Feature showcase with icon cards',
    category: 'Content',
    variants: ['grid', 'list', 'alternating'],
    defaultProps: { title: 'Features', subtitle: '', items: [] },
  },
  {
    type: 'pricing',
    label: 'Pricing',
    description: 'Pricing tiers with feature comparison',
    category: 'Commerce',
    variants: ['simple', 'comparison'],
    defaultProps: { title: 'Pricing', subtitle: 'Choose the plan that fits your needs' },
  },
  {
    type: 'cta',
    label: 'Call to Action',
    description: 'Conversion-focused section with CTA button',
    category: 'Conversion',
    variants: ['simple', 'split'],
    defaultProps: { headline: 'Ready to get started?', subheadline: '', buttonText: 'Learn more' },
  },
  {
    type: 'footer',
    label: 'Footer',
    description: 'Page footer with links and copyright',
    category: 'Navigation',
    variants: ['simple', 'multi-column', 'minimal', 'resources'],
    defaultProps: { logo: '', copyright: '', links: [] },
  },
  {
    type: 'testimonials',
    label: 'Testimonials',
    description: 'Customer testimonials with quotes and ratings',
    category: 'Social Proof',
    variants: ['cards', 'carousel', 'spotlight'],
    defaultProps: { title: 'Testimonials', items: [] },
  },
  {
    type: 'stats',
    label: 'Stats',
    description: 'Key metrics and statistics display',
    category: 'Social Proof',
    variants: ['grid', 'bar', 'counter'],
    defaultProps: { title: 'By the numbers', items: [] },
  },
  {
    type: 'faq',
    label: 'FAQ',
    description: 'Frequently asked questions accordion',
    category: 'Content',
    variants: ['accordion'],
    defaultProps: { title: 'Frequently Asked Questions', items: [] },
  },
  {
    type: 'team',
    label: 'Team',
    description: 'Team grid or staff directory with portraits and bios',
    category: 'Content',
    variants: ['grid', 'directory'],
    defaultProps: { title: 'Meet the Team', members: [] },
  },
  {
    type: 'contact',
    label: 'Contact',
    description: 'Contact form with name, email, and message',
    category: 'Forms',
    variants: ['form'],
    defaultProps: { title: 'Get in Touch', subtitle: "We'd love to hear from you." },
  },
  {
    type: 'newsletter',
    label: 'Newsletter',
    description: 'Email subscription form with social proof',
    category: 'Conversion',
    variants: ['simple'],
    defaultProps: { title: 'Stay in the loop', subtitle: '', buttonText: 'Subscribe' },
  },
  {
    type: 'logocloud',
    label: 'Logo Cloud',
    description: 'Company logos with hover effects',
    category: 'Social Proof',
    variants: ['default'],
    defaultProps: { title: 'Partners', logos: [] },
  },
  {
    type: 'content',
    label: 'Content',
    description: 'Rich text content section',
    category: 'Content',
    variants: ['prose', 'wide-prose', 'columns', 'highlight'],
    defaultProps: { body: '## Getting Started\n\nWrite your content here. Supports **bold**, *italic*, and lists.\n\n- First item\n- Second item\n- Third item' },
  },
  {
    type: 'image',
    label: 'Image',
    description: 'Image with text overlay or side-by-side layout',
    category: 'Media',
    variants: ['hero-image', 'side-by-side', 'grid'],
    defaultProps: { imageSide: 'left', layoutWidth: 40 },
  },
  {
    type: 'video',
    label: 'Video',
    description: 'Embedded YouTube or Vimeo video',
    category: 'Media',
    variants: ['youtube', 'vimeo'],
    defaultProps: { url: '', title: 'Watch Our Story' },
  },
  {
    type: 'gallery',
    label: 'Gallery',
    description: 'Image gallery in grid, masonry, or responsive layout',
    category: 'Media',
    variants: ['grid', 'masonry', 'responsive'],
    defaultProps: { title: 'Gallery' },
  },
  {
    type: 'divider',
    label: 'Strip',
    description: 'Separator or blank space between sections',
    category: 'Media',
    variants: ['space', 'line', 'dots'],
    defaultProps: { height: 60, width: 'full' },
  },
  {
    type: 'banner',
    label: 'Banner',
    description: 'Announcement bar or ribbon',
    category: 'Content',
    variants: ['ribbon', 'bar'],
    defaultProps: { text: 'Add your announcement', linkText: '' },
  },
]

export const categories = [...new Set(blockMetadata.map((b) => b.category))]
