export type BlockType =
  | 'navbar'
  | 'hero'
  | 'features'
  | 'pricing'
  | 'cta'
  | 'footer'
  | 'testimonials'
  | 'stats'
  | 'faq'
  | 'team'
  | 'contact'
  | 'newsletter'
  | 'logocloud'
  | 'divider'
  | 'banner'
  | 'content'
  | 'image'
  | 'video'
  | 'gallery'
  | 'collage'
  | 'panel'
  | 'pdfViewer'
  | 'document'
  | 'documentLibrary'
  | 'calendar'
  | 'audio'
  | 'mediaVideo'

export type BlockVariant = string

export interface NavigationDestination {
  label: string
  url: string
}

export interface CalendarEvent {
  id: string
  title: string
  date: string
  time?: string
  location?: string
  details?: string
}

export interface NavbarDestination extends NavigationDestination {
  children?: NavigationDestination[]
}

export interface BlockConfig {
  id: string
  type: BlockType
  variant: BlockVariant
  props: Record<string, unknown>
  webstudioSharedSectionId?: string
  webstudioHiddenOn?: { mobile?: boolean; tablet?: boolean; desktop?: boolean }
}

export interface ThemeConfig {
  // Backgrounds
  bg0: string
  bg1: string
  bg2: string
  bg3: string
  bg4: string
  bg5: string
  // Text
  text0: string
  text1: string
  text2: string
  text3: string
  // Accent
  accent: string
  accentDim: string
  // Borders
  borderDefault: string
  borderSubtle: string
  borderHover: string
  // Fonts
  fontSans: string
  fontDisplay: string
  fontMono: string
  // Radius
  radius: number
  radiusLg: number
}

export interface PageConfig {
  id: string
  name: string
  path: string
  blocks: BlockConfig[]
  webstudioSeo?: { title?: string; description?: string }
  webstudioCustomCode?: { html: string; css: string; js: string }
  webstudioArticle?: {
    status: 'draft' | 'ready'
    author: string
    summary: string
    tags?: string[]
    createdAt: string
    modifiedAt: string
  }
}

export interface SiteConfig {
  name: string
  pages?: PageConfig[]
  blocks: BlockConfig[]
  theme?: Partial<ThemeConfig>
  webstudioReusableSections?: { id: string; name: string; block: BlockConfig }[]
}
