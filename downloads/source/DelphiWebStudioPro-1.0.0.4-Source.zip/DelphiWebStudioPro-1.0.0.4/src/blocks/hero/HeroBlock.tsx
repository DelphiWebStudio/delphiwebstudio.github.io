import type { BlockConfig } from '../types'
import { RichText } from '../RichText'
import { ArrowRight, Sparkles } from 'lucide-react'

interface HeroProps {
  _blockId: string
  _editable: boolean
  _headlineRich?: unknown
  _subheadlineRich?: unknown
  headlineOffsetX?: number
  headlineOffsetY?: number
  headlineWidth?: number
  headlineHeight?: number
  headlineHidden?: boolean
  subheadlineOffsetX?: number
  subheadlineOffsetY?: number
  subheadlineWidth?: number
  subheadlineHeight?: number
  subheadlineHidden?: boolean
  headlineAlign?: unknown
  subheadlineAlign?: unknown
  badge?: string
  headline: string
  subheadline: string
  primaryCta: string
  primaryCtaUrl?: string
  secondaryCta?: string
  secondaryCtaUrl?: string
  heroImage?: string
}

function HeroCentered({ props }: { props: HeroProps }) {
  return (
    <section className="px-6 @md:px-10 py-20 @md:py-28 text-center">
      {/* Badge */}
      {props.badge && (
        <div className="reveal-fade-up reveal-d1 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green/10 border border-green/20 text-green text-[11px] font-medium mb-6">
          <Sparkles size={12} />
          {props.badge}
        </div>
      )}

      {/* Headline */}
      <h1 className="reveal-fade-up reveal-d2 text-4xl @md:text-5xl font-bold tracking-tight leading-[1.1] mb-4 mx-auto">
        {!props.headlineHidden && <RichText blockId={props._blockId} field="headline" text={props.headline || ''} value={props._headlineRich} alignment={props.headlineAlign} editable={props._editable} position={{ x: Number(props.headlineOffsetX) || 0, y: Number(props.headlineOffsetY) || 0, width: Number(props.headlineWidth) || undefined, height: Number(props.headlineHeight) || undefined }} />}
      </h1>

      {/* Subheadline */}
      <p className="reveal-fade-up reveal-d3 text-text-2 text-base @md:text-lg leading-relaxed max-w-xl mx-auto mb-8">
        {!props.subheadlineHidden && <RichText blockId={props._blockId} field="subheadline" text={props.subheadline || ''} value={props._subheadlineRich} alignment={props.subheadlineAlign} editable={props._editable} position={{ x: Number(props.subheadlineOffsetX) || 0, y: Number(props.subheadlineOffsetY) || 0, width: Number(props.subheadlineWidth) || undefined, height: Number(props.subheadlineHeight) || undefined }} />}
      </p>

      {/* CTAs */}
      <div className="reveal-fade-up reveal-d4 flex flex-wrap items-center justify-center gap-3">
        {props.primaryCta && <a data-ws-block-button href={props.primaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-green text-black text-sm font-semibold hover:bg-green-dim transition-all hover:accent-glow-xl flex items-center gap-2">
          {props.primaryCta}
          <ArrowRight size={16} />
        </a>}
        {props.secondaryCta && (
          <a data-ws-block-button href={props.secondaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-bg-3 text-text-0 text-sm font-medium border border-border-default hover:bg-bg-4 hover:border-border-hover transition-all">
            {props.secondaryCta}
          </a>
        )}
      </div>
    </section>
  )
}

function HeroSplit({ props }: { props: HeroProps }) {
  return (
    <section className="px-6 @md:px-10 py-16 @md:py-24 flex flex-col @2xl:flex-row items-center gap-10">
      {/* Text side */}
      <div className="flex-1">
        {props.badge && (
          <div className="reveal-fade-up reveal-d1 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green/10 border border-green/20 text-green text-[11px] font-medium mb-4">
            <Sparkles size={12} />
            {props.badge}
          </div>
        )}
        <h1 className="reveal-fade-up reveal-d2 text-3xl @md:text-5xl font-bold tracking-tight leading-[1.1] mb-4">
          {!props.headlineHidden && <RichText blockId={props._blockId} field="headline" text={props.headline || ''} value={props._headlineRich} alignment={props.headlineAlign} editable={props._editable} position={{ x: Number(props.headlineOffsetX) || 0, y: Number(props.headlineOffsetY) || 0, width: Number(props.headlineWidth) || undefined, height: Number(props.headlineHeight) || undefined }} />}
        </h1>
        <p className="reveal-fade-up reveal-d3 text-text-2 text-base leading-relaxed mb-6 max-w-lg">
          {!props.subheadlineHidden && <RichText blockId={props._blockId} field="subheadline" text={props.subheadline || ''} value={props._subheadlineRich} alignment={props.subheadlineAlign} editable={props._editable} position={{ x: Number(props.subheadlineOffsetX) || 0, y: Number(props.subheadlineOffsetY) || 0, width: Number(props.subheadlineWidth) || undefined, height: Number(props.subheadlineHeight) || undefined }} />}
        </p>
        <div className="reveal-fade-up reveal-d4 flex flex-wrap items-center gap-3">
          {props.primaryCta && <a data-ws-block-button href={props.primaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-green text-black text-sm font-semibold hover:bg-green-dim transition-all flex items-center gap-2">
            {props.primaryCta}
            <ArrowRight size={16} />
          </a>}
          {props.secondaryCta && (
            <a data-ws-block-button href={props.secondaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-bg-3 text-text-0 text-sm font-medium border border-border-default hover:bg-bg-4 transition-all">
              {props.secondaryCta}
            </a>
          )}
        </div>
      </div>

      {/* Visual side */}
      <div className="reveal-fade-up reveal-d3 flex-1 w-full">
        <div className="aspect-[4/3] rounded-xl bg-bg-2 border border-border-default overflow-hidden relative">
          {props.heroImage ? <img src={props.heroImage} alt="" className="absolute inset-0 w-full h-full object-cover" /> : <>
            <div className="absolute inset-0 bg-gradient-to-br from-green/5 to-transparent" />
            <div className="absolute inset-6 border border-dashed border-border-default rounded-lg flex items-center justify-center text-text-3 text-sm">Preview</div>
          </>}
        </div>
      </div>
    </section>
  )
}

function HeroGradient({ props }: { props: HeroProps }) {
  return (
    <section className="px-6 @md:px-10 py-20 @md:py-32 text-center relative overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-green/5 via-transparent to-transparent pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-green/8 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10">
        {props.badge && (
          <div className="reveal-fade-up reveal-d1 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green/10 border border-green/20 text-green text-[11px] font-medium mb-6">
            <Sparkles size={12} />
            {props.badge}
          </div>
        )}

        <h1 className="reveal-fade-up reveal-d2 text-4xl @md:text-5xl font-bold tracking-tight leading-[1.1] mb-4 mx-auto" style={{ color: 'var(--color-text-0)' }}>
          {!props.headlineHidden && <RichText blockId={props._blockId} field="headline" text={props.headline || ''} value={props._headlineRich} alignment={props.headlineAlign} editable={props._editable} position={{ x: Number(props.headlineOffsetX) || 0, y: Number(props.headlineOffsetY) || 0, width: Number(props.headlineWidth) || undefined, height: Number(props.headlineHeight) || undefined }} />}
        </h1>

        <p className="reveal-fade-up reveal-d3 text-text-2 text-base @md:text-lg leading-relaxed max-w-xl mx-auto mb-8">
          {!props.subheadlineHidden && <RichText blockId={props._blockId} field="subheadline" text={props.subheadline || ''} value={props._subheadlineRich} alignment={props.subheadlineAlign} editable={props._editable} position={{ x: Number(props.subheadlineOffsetX) || 0, y: Number(props.subheadlineOffsetY) || 0, width: Number(props.subheadlineWidth) || undefined, height: Number(props.subheadlineHeight) || undefined }} />}
        </p>

        <div className="reveal-fade-up reveal-d4 flex flex-wrap items-center justify-center gap-3">
          {props.primaryCta && <a data-ws-block-button href={props.primaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-green text-black text-sm font-semibold hover:bg-green-dim transition-all hover:accent-glow-xl flex items-center gap-2">
            {props.primaryCta}
            <ArrowRight size={16} />
          </a>}
          {props.secondaryCta && (
            <a data-ws-block-button href={props.secondaryCtaUrl || undefined} className="px-6 py-3 rounded-lg bg-bg-3 text-text-0 text-sm font-medium border border-border-default hover:bg-bg-4 transition-all">
              {props.secondaryCta}
            </a>
          )}
        </div>
      </div>
    </section>
  )
}

function HeroMinimal({ props }: { props: HeroProps }) {
  return (
    <section className="px-6 @md:px-10 py-24 @md:py-36 text-center">
      <h1 className="reveal-fade-up reveal-d1 text-5xl @md:text-7xl font-bold tracking-tighter leading-[1.05] mb-6 mx-auto">
        {!props.headlineHidden && <RichText blockId={props._blockId} field="headline" text={props.headline || ''} value={props._headlineRich} alignment={props.headlineAlign} editable={props._editable} position={{ x: Number(props.headlineOffsetX) || 0, y: Number(props.headlineOffsetY) || 0, width: Number(props.headlineWidth) || undefined, height: Number(props.headlineHeight) || undefined }} />}
      </h1>
      <p className="reveal-fade-up reveal-d2 text-text-2 text-lg @md:text-xl leading-relaxed max-w-lg mx-auto mb-10">
        {!props.subheadlineHidden && <RichText blockId={props._blockId} field="subheadline" text={props.subheadline || ''} value={props._subheadlineRich} alignment={props.subheadlineAlign} editable={props._editable} position={{ x: Number(props.subheadlineOffsetX) || 0, y: Number(props.subheadlineOffsetY) || 0, width: Number(props.subheadlineWidth) || undefined, height: Number(props.subheadlineHeight) || undefined }} />}
      </p>
      {props.primaryCta && <div className="reveal-fade-up reveal-d3">
        <a data-ws-block-button href={props.primaryCtaUrl || undefined} className="px-8 py-4 rounded-lg bg-green text-black text-sm font-semibold hover:bg-green-dim transition-all hover:accent-glow-xl inline-flex items-center gap-2 mx-auto">
          {props.primaryCta}
          <ArrowRight size={16} />
        </a>
      </div>}
    </section>
  )
}

export function HeroBlock({ block, editable = false }: { block: BlockConfig; editable?: boolean }) {
  const props = { ...block.props, primaryCta: block.props.primaryCta === 'Get Started' && !block.props.primaryCtaUrl ? '' : block.props.primaryCta, secondaryCta: block.props.secondaryCta === 'Learn More' && !block.props.secondaryCtaUrl ? '' : block.props.secondaryCta, _blockId: block.id, _editable: editable, _headlineRich: block.props.headlineRich, _subheadlineRich: block.props.subheadlineRich } as unknown as HeroProps

  switch (block.variant) {
    case 'split':
      return <HeroSplit props={props} />
    case 'gradient':
      return <HeroGradient props={props} />
    case 'minimal':
      return <HeroMinimal props={props} />
    default:
      return <HeroCentered props={props} />
  }
}
